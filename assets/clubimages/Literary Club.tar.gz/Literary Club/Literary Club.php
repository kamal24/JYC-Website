The JYC Literary Club is an amalgam of eloquence, talents and none the less dexterity. We have organized various events
like Debates, Parliamentary Discussions, Kavi Sammelan, Model United Nations Conference, Quizzes and various Literary as well as Fun events.

Each member of the club is outstanding, may it be debating, compering, anchoring, acting, writing etc. We work as a team and strive hard to make each of our events a grand success.