Sometimes, it's just a simple game. But often, sports is much more than that. It's full of life lessons. It can teach you about failure, joy, disappointment, excitement, winning and losing. About maturity, teamwork, humility and selflessness.
The functions of sports club need not to be explained as the name speaks for itself.  Sports club(2013-14) dynamically combines ample creativity, with pragmatic focus, enthusiasm and unwavering professionalism. We deliver the promised and better than expected results
Achievements of the club:
1) Parakram (2013)- with the innovative idea, vision and hard work, sports club(2013-14) organised a Sports Meet(Parakram) for the first time in JUIT history. We VIKAS SANGWAN and SONALEE MEHTA (sports club coordinators) on the behalf of sports club thank our faculty incharge, and complete JYC for their cooperation leading to the pronounced  success of Parakaram (2013).
2) Sports club organised various successful events like :
a) Dodge ball
b) Marathon(3 Km)
c) Blind drive
We look forward to organise many more amusing events in acedmic year (2013-14) like:
a) Sumo wrestling
b) Beer pong
c) French cricket
d) Tug of war
e) Ballon shoot
f) Ring runner
g) Casino royal
h) And many more........